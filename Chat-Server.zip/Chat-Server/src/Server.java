import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

import model.UserMessage;

public class Server {
    private List<ObjectOutputStream> outputStreams = new ArrayList<>();
    private ServerSocket serverSocket;

    public Server() {
        try {
            serverSocket = new ServerSocket(1111);
            start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void start() {
        while (true) {
            try {
                System.out.println("Waiting for connection...");
                Socket socket = serverSocket.accept();
                System.out.println("Client Connected");

                ObjectOutputStream outputStream = new ObjectOutputStream(socket.getOutputStream());
                outputStreams.add(outputStream);

                // Assign User identifier
                outputStream.writeObject(outputStream.hashCode());

                ObjectInputStream inputStream = new ObjectInputStream(socket.getInputStream());
                new ClientHandler(inputStream).start();

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private class ClientHandler extends Thread {
        private ObjectInputStream inputStream;

        public ClientHandler(ObjectInputStream inputStream) {
            this.inputStream = inputStream;
        }

        // Get Input, processes it and return Output
        // Input: Get UserMessage class
        // Output: Return only user message
        @Override
        public void run() {
            try {
                while (true) {
                    // Listen for new data from client
                    UserMessage userMessage = (UserMessage) inputStream.readObject(); // Input
                    System.out.println("Received data from client");

                    Stack<Integer> closedConnection = new Stack<>();
                    // Transfer the received data to all connected clients
                    for (int i = 0; i < outputStreams.size(); i++) {
                        ObjectOutputStream out = outputStreams.get(i);

                        // Handler when connections are closed
                        try {
                            if (userMessage.getId() != out.hashCode()) {
                                out.writeObject(userMessage); // Output
                                out.flush();
                            }
                        } catch (IOException e) {
                            closedConnection.push(i);
                        }
                    }

                    // Removing closed connection
                    while (!closedConnection.isEmpty()) {
                        outputStreams.remove(closedConnection.pop());
                        System.out.println("Removed closed Connection");
                    }
                }
            } catch (Exception e) {
                System.out.println("Connection is closed");
            }
        }
    }

    public static void main(String[] args) {
        new Server();
    }
}
